<?php
$conexao = mysqli_connect('localhost', 'root', 'pr0c0npb', 'np_proconpb');
