<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="app/assets/css/bootstrap.min.css" media="screen" title="no title">
    <link rel="stylesheet" href="app/assets/css/bootstrap-theme.min.css" media="screen" title="no title">
</head>
<body>
<table class="table table-striped table-bordered btn-primary">
  <legend>Listagem - Telefones á serem bloqueados ligações de telemarqueting</legend>
     <thead>
       <tr>
         <th>
           <p>CPF/CNPJ</p>
         </th>
         <th><th>
           <p>NUMERO</p>
         </th>
      </tr>
    </thead>
<tbody></body></html>
