<?php
$HOME = '
<a class="nav-item" href="login">
  <span>Home</span>
</a>';

  $LOGIN = '
  <a class="nav-item" href="login">
      <span>ENTRAR</span>
  </a>';

  // $LOGIN = '<li><a href="login">Logar</a></li>';
  include_once ('app/view/partlals/header.php') ?>
  <h1>404 Pagina Não encontrada!</h1>
<?php include_once ('app/view/partlals/footer.php') ?>
