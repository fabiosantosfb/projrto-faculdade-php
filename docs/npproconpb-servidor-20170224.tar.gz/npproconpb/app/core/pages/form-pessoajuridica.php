<?php

$PESSOA = '
<a class="nav-item is-active" href="pessoa-fisica">
    <span>Pessoa Física</span>
</a>
';

$LOGIN = '
<a class="nav-item" href="login">
    <span>ENTRAR</span>
</a>';

require_once ('app/view/view-form-pj.php');
