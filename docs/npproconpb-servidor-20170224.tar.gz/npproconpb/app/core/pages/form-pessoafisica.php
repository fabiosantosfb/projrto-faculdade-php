<?php
    $PESSOA = '
    <a class="nav-item" href="pessoa-juridica">
        <span>Pessoa Jurídica</span>
    </a>
    ';


    $LOGIN = '
    <a class="nav-item" href="login">
        <span>ENTRAR</span>
    </a>';

require_once ('app/view/view-form-pf.php');
