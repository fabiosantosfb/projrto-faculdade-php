<?php
$LOGIN = '
<a class="nav-item" href="login">
    <span>ENTRAR</span>
</a>';

$PESSOA = '
<a class="nav-item" href="pessoa-fisica">
    <span>Pessoa Física</span>
</a>
';

require_once ('app/view/view-form-pj.php');
