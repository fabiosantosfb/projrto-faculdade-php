<?php
$PESSOA = '
<a class="nav-item" href="pessoa-fisica">
    <span>Pessoa Física</span>
</a>
<a class="nav-item is-active" href="pessoa-juridica">
    <span>Pessoa Jurídica</span>
</a>
';

$LOGIN = '';

require ('app/view/view-form-login.php');
